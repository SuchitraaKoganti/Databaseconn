﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace Databaseconnectivitysampledemo
{
    public partial class SearchStudent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        SqlCommand cmd = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

       

        protected void btUpdate_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("update mohanapriya.DBemployees set empName=@EName,empCity=@ECity,empPhone=@EPhone,empDOJ=@EDOJ where empID=@EID", con);
            cmd.Parameters.AddWithValue("@EName", txtName.Text);
            cmd.Parameters.AddWithValue("@ECity", txtCity.Text);
            cmd.Parameters.AddWithValue("@EDOJ", Convert.ToDateTime(txtDOJ.Text));

            cmd.Parameters.AddWithValue("@EPhone", txtPhone.Text);
            cmd.Parameters.AddWithValue("@EID", txtID.Text);
            con.Open();
            int recordafftected = cmd.ExecuteNonQuery();
            con.Close();
            if (recordafftected > 0)
            {
                Response.Write("<SCRIPT type='text/javaScript'>alert('Employee Data updated for empID" + txtID.Text + "');</SCRIPT>");
                txtName.Enabled = false;
                txtCity.Enabled = false;
                txtPhone.Enabled = false;
                txtDOJ.Enabled = false;
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }
            else
                Response.Write("<SCRIPT type='text/javaScript'>alert('Employee Data not updated for empID" + txtID.Text + "');</SCRIPT>");

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("delete from mohanapriya.DBemployees where empID=@EID", con);
            cmd.Parameters.AddWithValue("@EID", txtID.Text);
            con.Open();
            int rowsaffected = cmd.ExecuteNonQuery();

            if (rowsaffected > 0)
            {
                Response.Write("<SCRIPT type='text/javaScript'>alert('Employee Data deleted for empID" + txtID.Text + "');</SCRIPT>");
                txtName.Enabled = false;
                txtCity.Enabled = false;
                txtPhone.Enabled = false;
                txtDOJ.Enabled = false;
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }
            else
                Response.Write("<SCRIPT type='text/javaScript'>alert('Employee Data not deleted for empID" + txtID.Text + "');</SCRIPT>");
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("Select * from mohanapriya.DBemployees where empID=@EID", con);
            cmd.Parameters.AddWithValue("@EID", txtID.Text);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                dr.Read();
                txtName.Text = dr["empName"].ToString();
                txtCity.Text = dr["empCity"].ToString();
                txtPhone.Text = dr["empPhone"].ToString();
                txtDOJ.Text = dr["empDOJ"].ToString();
                txtName.Enabled = true;
                txtCity.Enabled = true;
                txtPhone.Enabled = true;
                txtDOJ.Enabled = true;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }
            else
                Response.Write("<SCRIPT type='text/javaScript'>alert('Student Data not found for Stud Code" + txtID.Text + "');</SCRIPT>");
        }
    }
    }

 

    //protected void btnSearch_Click(object sender, EventArgs e)
    //    {

    //    }

    //    protected void btUpdate_Click(object sender, EventArgs e)
    //    {

    //    }

    //    protected void btnDelete_Click(object sender, EventArgs e)
    //    {

    //    }
    
