﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Databaseconnectivitysampledemo
{
    public partial class InsertStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
            SqlCommand cmd = new SqlCommand("insert into mohanapriya.DBemployees(empName,empID,empCity,empPhone,empDOJ) Values (@EName,@EID,@ECity,@EPhone,@EDOJ)", con);
            cmd.Parameters.AddWithValue("@EName", txtName.Text);
            cmd.Parameters.AddWithValue("@EID", txtID.Text);
            cmd.Parameters.AddWithValue("@ECity", txtCity.Text);
            cmd.Parameters.AddWithValue("@EPhone", txtPhone.Text);
            cmd.Parameters.AddWithValue("@EDOJ", Convert.ToDateTime(txtDOJ.Text));
            
            con.Open();
            int recordsaffected = cmd.ExecuteNonQuery();
            con.Close();
            if (recordsaffected > 0)
            {
                Response.Write("<SCRIPT type='text/javaScript'>alert('Employee Data inserted successfully');</SCRIPT>");
            }
            else
                Response.Write("<SCRIPT type='text/javaScript'>alert('Employee Data not inserted');</SCRIPT>");


        }
    }
}